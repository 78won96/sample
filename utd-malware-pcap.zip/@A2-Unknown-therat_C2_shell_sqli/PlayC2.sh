#C2FILE=`find /home/lab/Threat-Replay/ATP/ -name "*.pcap" -size -350k | shuf -n 1`
C2FILE1=`find /home/lab/Threat-Replay/ATP/MLC2/CS-HTTP/ -name "*.pcap" -size -350k | shuf -n 1`
C2FILE2=`find /home/lab/Threat-Replay/ATP/MLC2/unknown-TCP/ -name "*.pcap" -size -350k | shuf -n 1`
echo "Playing C2 file `basename -a $C2FILE1`"
sudo tcpreplay --stats=10 -i ens224 -p 100 "$C2FILE1"
sleep 3
echo "Playing C2 file `basename -a $C2FILE2`"
sudo tcpreplay --stats=10 -i ens224 -p 100 "$C2FILE2"
