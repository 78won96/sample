#!/bin/bash
sudo docker run -p 8000:80 -t adv-url-demo:latest
